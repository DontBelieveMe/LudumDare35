<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Level" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="Level.png" width="256" height="256"/>
 <tile id="0">
  <properties>
   <property name="isSolid" value="false"/>
  </properties>
 </tile>
</tileset>
